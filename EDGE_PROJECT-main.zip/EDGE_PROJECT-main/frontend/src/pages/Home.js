import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Online Stationary Shop</h1>
      <p>Your one-stop shop for all your stationary needs!</p>
    </div>
  );
};

export default Home;
